$(document).ready(function(){
    $('#footer').load("/pages/components/footer.html");
});