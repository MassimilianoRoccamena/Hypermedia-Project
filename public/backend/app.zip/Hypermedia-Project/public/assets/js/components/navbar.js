$(document).ready(function(){
    $('#navbar').load("/pages/components/navbar.html");
});